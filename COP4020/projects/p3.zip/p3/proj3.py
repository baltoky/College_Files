from tkinter import Tk, Canvas, Frame, BOTH, LAST, W
from collections import deque
from random import randint
import re
import math

class Scene(Frame):
	def __init__(self):
		super().__init__()
		self.initUI()
		
	def initUI(self):
		rad = 25
		scale = 1
		self.master.title("Lines")
		self.pack(fill=BOTH, expand=1)
		f = open("newTokens.txt", "r")
		testF = open("test.txt", "r")
		testString = testF.read()
		tokens = f.read()
		tokenList = re.split(';', tokens)
		temp = []
		canvas = Canvas(self)
		automata = []
		states = []
		for tok in tokenList:
			print(tok.strip(' '))
		
		temp.append(tokenList[0])
		numOfA = int(temp[0])
		
		
		canvas.create_text(350, 10, anchor = W, font = "Comic", text = tokenList[1])
		
		'''
		for tok in tokenList:
			tok = tok.strip('(')
			tok = tok.strip(')')
			temp.append(tok)
		'''
        
		endStates = re.split(',', tokenList[4])
		for num in range(numOfA):
			x = 50 * scale
			y = 50 * scale
			scale += 1
			automata.append(Automata(radius = rad, position = Vector(x, y), canvasInput = canvas, token = str(num)))

		for token in endStates:
			automata[int(token)].end = True

		for circles in automata:
			circles.draw()
            
		states = re.split(',', tokenList[2])
		relations = []
		stateCount = 0
		for s in states:
			temp = s.strip('(|)')
			print("\n" + temp)
			temp2 = re.split(':', temp)
			tok = temp2[2]
			r = Relation(initialVector = automata[int(temp2[0])], finalVector = automata[int(temp2[1])],
			canvasInput = canvas, initalState = int(temp2[0]), finalState = int(temp2[1]), radius = automata[int(temp2[0])].rad, token = tok)
			r.draw()
			relations.append(r)
			stateCount += 1
		
		currentA = int(tokenList[3])
		print(testString)
		print(endStates)
		ended = False
		error = False
		for letter in testString:
			found = False
			for r in relations:
				if(letter == r.tok and currentA == r.i):
					currentA = r.f
					print("Token: " + letter + " goes from: " + str(r.i) + " to " + str(r.f))
					found = True
			if(not found): 
				print("What the fuck you nimwit, this is not in the language....")
				error = True
				break
		for tok in endStates:
			if(currentA == int(tok) and (not error)):
				ended = True
				print("This string is ... acceptable.")
        
		canvas.pack(fill=BOTH, expand=1)

def main():
	root = Tk()
	ex = Scene()
	root.geometry("400x400")
	root.mainloop()

class Vector:
	def __init__(self, _x, _y, _t_x = 0, _t_y = 0):
		self.x = _x
		self.y = _y
		self.t_x = _t_x
		self.t_y = _t_y
		
	def getMagnitude(self):
		mag = math.sqrt(math.pow(self.x - self.t_x, 2) + math.pow(self.y - self.t_y, 2))
		return mag
		
	def asUnitVector(self):
		x = self.x / self.getMagnitude()
		y = self.y / self.getMagnitude()
		return Vector(x, y)
	
	def subtract(self, vector):
		newVector = Vector(self.x - vector.y, self.y - vector.y)
		return newVector

class Automata:
	def __init__(self, radius, position, canvasInput, token = "1", isEnd = False):
		self.rad = radius
		self.pos = position
		self.x = position.x
		self.y = position.y
		self.tok = token
		self.end = isEnd
		self.canvas = canvasInput
		
	def draw(self):
		if(self.end):
			self.rad += 4
			self.canvas.create_oval(self.x - self.rad, self.y - self.rad, self.x + self.rad, self.y + self.rad, fill="White")
			self.rad -= 4
		self.canvas.create_oval(self.x - self.rad, self.y - self.rad, self.x + self.rad, self.y + self.rad, fill="White")
		self.canvas.create_text(self.x - 5, self.y, anchor = W, font = "Comic", text = self.tok)
		
class Relation:
	def __init__(self, initialVector, finalVector, initalState, finalState, canvasInput, radius, token):
		self.rad = radius
		self.i = initalState
		self.f = finalState
		self.vector = Vector(initialVector.x, initialVector.y, finalVector.x, finalVector.y)
		self.canvas = canvasInput
		print("I: " + str(initialVector.x) + ", " + str(initialVector.y))
		print("I: " + str(finalVector.x) + ", " + str(finalVector.y))
		self.tok = token
	
	def draw(self):
		if(self.i == self.f):
			print("Am blue daba di dabu da")
			self.canvas.create_line(self.vector.x + self.rad, self.vector.y,
			self.vector.x + self.rad + 20, self.vector.y - self.rad - 20,
			self.vector.t_x, self.vector.t_y - self.rad, 
			arrow = LAST, smooth = "true")
		elif(self.vector.getMagnitude() > 75):
			self.canvas.create_line(self.vector.x + self.rad * math.cos(math.pi/4), self.vector.y - self.rad * math.sin(math.pi/4),
			(abs(self.vector.x - self.vector.t_x)) + self.rad  + 40, (abs(self.vector.y - self.vector.t_y)) - self.rad - 40,
			self.vector.t_x + self.rad * math.cos(math.pi/4), self.vector.t_y - self.rad * math.sin(math.pi/4), arrow = LAST, smooth = "true")
		else:
			self.canvas.create_line(self.vector.x + self.rad * math.cos(math.pi/4), self.vector.y + self.rad * math.sin(math.pi/4),
			self.vector.t_x - self.rad * math.cos(math.pi/4), self.vector.t_y - self.rad * math.sin(math.pi/4), arrow = LAST, smooth = "true")

if __name__ == '__main__':
    main()
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	