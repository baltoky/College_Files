
./Project2 legal1.in

./Project2 legal2.in

./Project2 legal3.in

./Project2 legal4.in

