
make clean
make

./p2_1.sh
./p2_2.sh

