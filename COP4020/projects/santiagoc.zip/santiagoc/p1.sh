#! /bin/bash

make
./Project1 legal1
./Project1 legal2
./Project1 legal3
./Project1 legal4
./Project1 illegal1
./Project1 illegal2
./Project1 illegal3
./Project1 illegal4

