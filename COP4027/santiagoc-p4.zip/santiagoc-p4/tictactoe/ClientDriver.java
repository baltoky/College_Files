package tictactoe;

/**
 * Student Name: Cesar Santiago
 * File Name: ClientDriver.java
 * Assignment Number: 4
 * 
 * This is the Driver to the Client which starts the Client application
 */

public class ClientDriver {

    public static void main(String args[]) {
		ClientApp app = new ClientApp();
		app.runClientApp();
    }
}
