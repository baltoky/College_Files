package reflection_DB;

/**
Student Name: Cesar Santiago
File Name: Main.java
Assignment number 1

Main class, opens the program's process.
*/

public class Main {
	
	/**
	 * @param args
	 * Initializes the program.
	 */
	public static void main(String[] args) {
		Driver.run(args);
	}
	
}
