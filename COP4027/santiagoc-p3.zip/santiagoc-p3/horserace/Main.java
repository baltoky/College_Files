package horserace;

import java.util.ArrayList;

/**
 * Student Name: Cesar Santiago
 * File Name: Main.java
 * Assignment Number: 3
 * 
 * The class that runs the main function and creates the process that runs the program.
 */
public class Main {
	public static void main(String[] args) {
		Driver.renderRace();
	}
}
