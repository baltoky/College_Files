#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <math.h>

#include "part1.h" 

int main(int argc, char** argv)
{
	part1();
	return 0;
}
